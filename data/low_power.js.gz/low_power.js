/**
 * Debug flag for captive portal.
 * @type {boolean}
 */
var captivePortalDebug = false;

/**
 * Flag to force captive portal debug mode.
 * @type {boolean}
 */
var forcedCaptivePortalDebug = false;

/**
 * Flag indicating if the captive portal is active.
 * @type {boolean}
 */
var captivePortalActive = false;

/**
 * Flag to force the captive portal to be active.
 * @type {boolean}
 */
var forcedCaptivePortal = false;

/**
 * Flag indicating if the captive portal has no timeout.
 * @type {boolean}
 */
var captivePortalNoTimeout = false;

/**
 * Flag to force the captive portal to have no timeout.
 * @type {boolean}
 */
var forcedCaptivePortalNoTimeout = false;

/**
 * Flag to control relaxed security mode.
 * @type {boolean}
 */
var relaxedSecurity = false;

/**
 * Flag enabled by the URL parameter "relaxedSecurity" to force relaxed security mode.
 * @type {boolean}
 */
var forcedRelaxedSecurity = false;

/**
 * Flag to control captive portal test mode.
 * @type {boolean}
 */
var forceCaptivePortalActive = false;

/**
 * Flag to enable debug output in the console for preferences.
 * @type {boolean}
 */
var preferencesDebug = false;

/**
 * Global object to store the captive portal status.
 * @type {Object}
 * @property {number} captivePortalTimeLeft - Time left for the captive portal.
 */
var captivePortalStatus = {
    captivePortalTimeLeft: 0
};

/**
 * Global object to store the previous state.
 * @type {Object}
 * @property {boolean} forceCaptivePortalActive - Previous state of forceCaptivePortalActive.
 * @property {boolean} captivePortalActive - Previous state of captivePortalActive.
 * @property {boolean} forcedCaptivePortal - Previous state of forcedCaptivePortal.
 * @property {boolean} captivePortalDebug - Previous state of captivePortalDebug.
 * @property {boolean} relaxedSecurity - Previous state of relaxedSecurity.
 * @property {boolean} forcedCaptivePortalDebug - Previous state of forcedCaptivePortalDebug.
 * @property {boolean} captivePortalNoTimeout - Previous state of captivePortalNoTimeout.
 */
var previousData = {
    forceCaptivePortalActive: false,
    captivePortalActive: false,
    forcedCaptivePortal: false,
    captivePortalDebug: false,
    relaxedSecurity: false,
    forcedCaptivePortalDebug: false,
    captivePortalNoTimeout: false
};

/**
 * Global object to store the CO2 Gadget features supported by the device (selected at compile time).
 * @type {Object}
 * @property {boolean} SUPPORT_BLE - Whether BLE is supported.
 * @property {boolean} SUPPORT_BUZZER - Whether a buzzer is supported.
 * @property {boolean} SUPPORT_ESPNOW - Whether ESP-NOW is supported.
 * @property {boolean} SUPPORT_MDNS - Whether mDNS is supported.
 * @property {boolean} SUPPORT_MQTT - Whether MQTT is supported.
 * @property {boolean} SUPPORT_MQTT_DISCOVERY - Whether MQTT Discovery is supported.
 * @property {boolean} SUPPORT_OTA - Whether OTA updates are supported.
 * @property {boolean} SUPPORT_LOW_POWER - Whether low power mode is supported.
 */
var features = {
    SUPPORT_BLE: false,
    SUPPORT_BUZZER: false,
    SUPPORT_ESPNOW: false,
    SUPPORT_MDNS: false,
    SUPPORT_MQTT: false,
    SUPPORT_MQTT_DISCOVERY: false,
    SUPPORT_OTA: false,
    SUPPORT_LOW_POWER: false
};

/**
 * Restarts the ESP32 device after user confirmation.
 */
function restartESP32() {
    const isConfirmed = confirm("Are you sure you want to restart the ESP32?");
    if (isConfirmed) {
        if (preferencesDebug) console.log("Restarting ESP32...");
        fetch('/restart', {
            method: 'GET',
            headers: {
                'Content-Type': 'text/plain'
            }
        })
            .then(response => {
                if (response.ok) {
                    console.log('ESP32 restart initiated');
                } else {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
            })
            .catch(error => console.error('Error restarting ESP32:', error));
    }
}

/**
 * Adds the 'active' class to the current page link in the navigation bar.
 */
function highlightCurrentPage() {
    const currentPage = window.location.pathname.split("/").pop();
    const navLinks = document.querySelectorAll(".navbar .nav-content a");

    navLinks.forEach(link => {
        if (link.getAttribute("href") === currentPage) {
            link.classList.add("active");
        }
    });
}

/**
 * Loads features from the server and updates the global features object.
 */
function loadFeaturesFromServer() {
    fetch('/getFeaturesAsJson')
        .then(response => response.json())
        .then(data => {
            console.log('Fetching loadFeaturesFromServer successful!');
            features.SUPPORT_BLE = data.BLE !== undefined ? data.BLE : false;
            features.SUPPORT_BUZZER = data.Buzzer !== undefined ? data.Buzzer : false;
            features.SUPPORT_ESPNOW = data.EspNow !== undefined ? data.EspNow : false;
            features.SUPPORT_MDNS = data.mDNS !== undefined ? data.mDNS : false;
            features.SUPPORT_MQTT = data.MQTT !== undefined ? data.MQTT : false;
            features.SUPPORT_MQTT_DISCOVERY = data.MQTTDiscovery !== undefined ? data.MQTTDiscovery : false;
            features.SUPPORT_OTA = data.OTA !== undefined ? data.OTA : false;
            features.SUPPORT_LOW_POWER = data.LowPower !== undefined ? data.LowPower : false;
        })
        .catch(error => console.error('Error fetching features:', error));
}

/**
 * Fetches the battery voltage from the server.
 * @returns {Promise<string>} A promise that resolves to the battery voltage as a string.
 * @throws {Error} If the network response is not ok or if there is an error fetching the data.
 */
function readBatteryVoltage() {
    return fetch('/readBatteryVoltage')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok.');
            }
            return response.text();
        })
        .catch(error => {
            console.error('Error fetching battery voltage:', error);
            throw error;
        });
}

/**
 * Fetches CO2 data from the server.
 * @returns {Promise<string>} A promise that resolves to the CO2 value as a string.
 */
function readCO2Data() {
    return fetch("/readCO2")
        .then(response => {
            if (!response.ok) {
                throw new Error("Network response was not ok.");
            }
            return response.text();
        })
        .then(data => parseFloat(data))
        .catch(error => {
            console.error("Error fetching CO2 data:", error);
            throw error;
        });
}

/**
 * Fetches temperature data from the server.
 * @returns {Promise<number>} A promise that resolves to the temperature value.
 */
function readTemperatureData() {
    return fetch("/readTemperature")
        .then(response => {
            if (!response.ok) {
                throw new Error("Network response was not ok.");
            }
            return response.text();
        })
        .then(data => parseFloat(data).toFixed(1))
        .catch(error => {
            console.error("Error fetching temperature data:", error);
            throw error;
        });
}

/**
 * Fetches humidity data from the server.
 * @returns {Promise<string>} A promise that resolves to the humidity value as a string.
 */
function readHumidityData() {
    return fetch("/readHumidity")
        .then(response => {
            if (!response.ok) {
                throw new Error("Network response was not ok.");
            }
            return response.text();
        })
        .then(data => parseFloat(data).toFixed(0))
        .catch(error => {
            console.error("Error fetching humidity data:", error);
            throw error;
        });
}

/**
 * Reads the measurement interval from the server.
 * @returns {Promise<number>} A promise that resolves to the measurement interval in milliseconds.
 * @throws {Error} If the network response is not ok or an error occurs during the fetch operation.
 */
function readMeasurementInterval() {
    return fetch("/getMeasurementInterval")
        .then(response => {
            if (!response.ok) {
                throw new Error("Network response was not ok.");
            }
            return response.text();
        })
        .then(data => parseInt(data) * 1000)
        .catch(error => {
            console.error("Error fetching measurement interval:", error);
            throw error;
        });
}

/**
 * Fetches the free heap memory from the server.
 * @returns {Promise<string>} A promise that resolves to the free heap memory as a string.
 * @throws {Error} If the network response is not ok or if there is an error fetching the data.
 */
function readFreeHeap() {
    return fetch('/getFreeHeap')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok.');
            }
            return response.text();
        })
        .catch(error => {
            console.error('Error fetching free heap:', error);
            throw error;
        });
}

/**
 * Fetches the minimum free heap memory from the server.
 * @returns {Promise<string>} A promise that resolves to the minimum free heap memory as a string.
 * @throws {Error} If the network response is not ok or if there is an error fetching the data.
 */
function readMinFreeHeap() {
    return fetch('/getMinFreeHeap')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok.');
            }
            return response.text();
        })
        .catch(error => {
            console.error('Error fetching min free heap:', error);
            throw error;
        });
}

/**
 * Handles the features data and updates the SUPPORT_* properties accordingly.
 * @param {Object} data - The features data object.
 */
function handleFeaturesData(data) {
    features.SUPPORT_BLE = data.BLE !== undefined ? data.BLE : false;
    features.SUPPORT_BUZZER = data.Buzzer !== undefined ? data.Buzzer : false;
    features.SUPPORT_ESPNOW = data.EspNow !== undefined ? data.EspNow : false;
    features.SUPPORT_MDNS = data.mDNS !== undefined ? data.mDNS : false;
    features.SUPPORT_MQTT = data.MQTT !== undefined ? data.MQTT : false;
    features.SUPPORT_MQTT_DISCOVERY = data.MQTTDiscovery !== undefined ? data.MQTTDiscovery : false;
    features.SUPPORT_OTA = data.OTA !== undefined ? data.OTA : false;
    features.SUPPORT_LOW_POWER = data.LowPower !== undefined ? data.LowPower : false;

    if (captivePortalDebug) console.log('Mapped Features:', features);
}

/**
 * Fetches features as JSON from the server and processes the data.
 * @returns {Promise<void>}
 */
function getFeaturesAsJson() {
    return fetch("/getFeaturesAsJson")
        .then(response => {
            if (!response.ok) {
                console.error("Response not OK:", response.status, response.statusText);
                throw new Error("Network response was not ok " + response.statusText);
            }
            return response.json();
        })
        .then(data => {
            console.log("Received JSON:", data);
            handleFeaturesData(data);
        })
        .catch(error => {
            console.error("Error fetching CO2 Gadget features:", error);
        });
}

/**
 * Fetches the version information from the server.
 * @returns {Promise<Object>} A promise that resolves to the version information object.
 * @throws {Error} If the network response is not ok or if there is an error fetching the version.
 */
function fetchVersion() {
    return fetch('/getVersion')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok.');
            }
            if (captivePortalDebug) console.log('Version information:', response.json());
            return response.json();
        })
        .catch(error => {
            console.error('Error fetching version:', error);
            throw error;
        });
}

/**
 * Retrieves the version string of the firmware.
 * @returns {Promise<string>} A promise that resolves to the version string.
 * @throws {Error} If there is an error getting the version string.
 */
function getVersionStr() {
    return fetchVersion()
        .then(versionInfo => {
            let versionText = `v${versionInfo.firmVerMajor}.${versionInfo.firmVerMinor}.${versionInfo.firmRevision}`;
            if (versionInfo.firmBranch) {
                versionText += `-${versionInfo.firmBranch}`;
            }
            versionText += ` (Flavour: ${versionInfo.firmFlavour})`;
            if (captivePortalDebug) console.log('Version string:', versionText);
            return versionText;
        })
        .catch(error => {
            console.error('Error getting version as string:', error);
            throw error;
        });
}

/**
 * Retrieves a JSON from the server with the current settings
 * and returns a promise that resolves to the JSON object.
 * @returns {Promise<Object>} A promise that resolves to the settings JSON object.
 */
function readPreferencesFromServer() {
    return fetch('/getActualSettingsAsJson')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok.');
            }
            return response.json();
        })
        .catch(error => {
            console.error('Error fetching preferences:', error);
            throw error;
        });
}

/**
 * Initialize the navbar based on the features supported by the device.
 */
function initNavBar() {
    if (captivePortalDebug)
        console.log("Document loaded. Initializing navbar...");

    if (features.SUPPORT_OTA) {
        const otaLink = document.getElementById("otaLink");
        if (otaLink) {
            otaLink.classList.remove("hidden")
        } else {
            console.error('Element with ID "otaLink" not found.')
        }
    }

    if (features.SUPPORT_LOW_POWER) {
        const lowPowerLink = document.getElementById("lowPowerLink");
        if (lowPowerLink) {
            lowPowerLink.classList.remove("hidden")
        } else {
            console.error('Element with ID "lowPowerLink" not found.')
        }

        const lowPowerIcon = document.getElementById("iconLighting");
        if (lowPowerIcon) {
            lowPowerIcon.classList.remove("hidden");
        } else {
            console.error('Element with ID "iconLighting" not found.')
        }
    }
}

/**
 * Handles the low power mode activation.
 */
function goLowPower() {
    console.log("Low power mode activated");
    fetch('/goLowPower', {
        method: 'GET',
        headers: {
            'Content-Type': 'text/plain'
        }
    })
        .then(response => {
            if (response.ok) {
                console.log('Low power mode activated');
            } else {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
        })
        .catch(error => console.error('Error activating low power mode:', error));
}

document.addEventListener("DOMContentLoaded", function () {
    getFeaturesAsJson().then(initNavBar);

    // Add device hostName to the existing page title as document.title + (HostName)
    readPreferencesFromServer().then(data => {
        document.title += ` (${data.hostName})`;
    });

    // Llamar a la funciÃ³n goLowPower al hacer clic en el icono de bajo consumo
    document.getElementById('lightingIcon').addEventListener('click', goLowPower);
});

const lightThemeIconPath = `M375.7 19.7c-1.5-8-6.9-14.7-14.4-17.8s-16.1-2.2-22.8 2.4L256 61.1 173.5 4.2c-6.7-4.6-15.3-5.5-22.8-2.4s-12.9 9.8-14.4 17.8l-18.1 98.5L19.7 136.3c-8 1.5-14.7 6.9-17.8 14.4s-2.2 16.1 2.4 22.8L61.1 256 4.2 338.5c-4.6 6.7-5.5 15.3-2.4 22.8s9.8 13 17.8 14.4l98.5 18.1 18.1 98.5c1.5 8 6.9 14.7 14.4 17.8s16.1 2.2 22.8-2.4L256 450.9l82.5 56.9c6.7 4.6 15.3 5.5 22.8 2.4s12.9-9.8 14.4-17.8l18.1-98.5 98.5-18.1c8-1.5 14.7-6.9 17.8-14.4s2.2-16.1-2.4-22.8L450.9 256l56.9-82.5c4.6-6.7 5.5-15.3 2.4-22.8s-9.8-12.9-17.8-14.4l-98.5-18.1L375.7 19.7zM269.6 110l65.6-45.2 14.4 78.3c1.8 9.8 9.5 17.5 19.3 19.3l78.3 14.4L402 242.4c-5.7 8.2-5.7 19 0 27.2l45.2 65.6-78.3 14.4c-9.8 1.8-17.5 9.5-19.3 19.3l-14.4 78.3L269.6 402c-8.2-5.7-19-5.7-27.2 0l-65.6 45.2-14.4-78.3c-1.8-9.8-9.5-17.5-19.3-19.3L64.8 335.2 110 269.6c5.7-8.2 5.7-19 0-27.2L64.8 176.8l78.3-14.4c9.8-1.8 17.5-9.5 19.3-19.3l14.4-78.3L242.4 110c8.2 5.7 19 5.7 27.2 0zM256 368a112 112 0 1 0 0-224 112 112 0 1 0 0 224zM192 256a64 64 0 1 1 128 0 64 64 0 1 1 -128 0z`;
const darkThemeIconPath = `M144.7 98.7c-21 34.1-33.1 74.3-33.1 117.3c0 98 62.8 181.4 150.4 211.7c-12.4 2.8-25.3 4.3-38.6 4.3C126.6 432 48 353.3 48 256c0-68.9 39.4-128.4 96.8-157.3zm62.1-66C91.1 41.2 0 137.9 0 256C0 379.7 100 480 223.5 480c47.8 0 92-15 128.4-40.6c1.9-1.3 3.7-2.7 5.5-4c4.8-3.6 9.4-7.4 13.9-11.4c2.7-2.4 5.3-4.8 7.9-7.3c5-4.9 6.3-12.5 3.1-18.7s-10.1-9.7-17-8.5c-3.7 .6-7.4 1.2-11.1 1.6c-5 .5-10.1 .9-15.3 1c-1.2 0-2.5 0-3.7 0c-.1 0-.2 0-.3 0c-96.8-.2-175.2-78.9-175.2-176c0-54.8 24.9-103.7 64.1-136c1-.9 2.1-1.7 3.2-2.6c4-3.2 8.2-6.2 12.5-9c3.1-2 6.3-4 9.6-5.8c6.1-3.5 9.2-10.5 7.7-17.3s-7.3-11.9-14.3-12.5c-3.6-.3-7.1-.5-10.7-.6c-2.7-.1-5.5-.1-8.2-.1c-3.3 0-6.5 .1-9.8 .2c-2.3 .1-4.6 .2-6.9 .4z`;

const lightLowPowerIconPath = `M0 256L28.5 28c2-16 15.6-28 31.8-28H228.9c15 0 27.1 12.1 27.1 27.1c0 3.2-.6 6.5-1.7 9.5L208 160H347.3c20.2 0 36.7 16.4 36.7 36.7c0 7.4-2.2 14.6-6.4 20.7l-192.2 281c-5.9 8.6-15.6 13.7-25.9 13.7h-2.9c-15.7 0-28.5-12.8-28.5-28.5c0-2.3 .3-4.6 .9-6.9L176 288H32c-17.7 0-32-14.3-32-32z`;
const darkLowPowerIconPath = `M0 256L28.5 28c2-16 15.6-28 31.8-28H228.9c15 0 27.1 12.1 27.1 27.1c0 3.2-.6 6.5-1.7 9.5L208 160H347.3c20.2 0 36.7 16.4 36.7 36.7c0 7.4-2.2 14.6-6.4 20.7l-192.2 281c-5.9 8.6-15.6 13.7-25.9 13.7h-2.9c-15.7 0-28.5-12.8-28.5-28.5c0-2.3 .3-4.6 .9-6.9L176 288H32c-17.7 0-32-14.3-32-32z`;

/**
 * Set the theme icon based on the current theme.
 * @param {string} theme - The current theme ("light" or "dark").
 */
function setThemeIcon(theme) {
    const iconPath = document.getElementById("iconPath");
    const themeIcon = document.getElementById("themeIcon");
    if (theme === "dark") {
        themeIcon.setAttribute("viewBox", "0 0 384 512");
        iconPath.setAttribute("d", darkThemeIconPath);
    } else {
        themeIcon.setAttribute("viewBox", "0 0 512 512");
        iconPath.setAttribute("d", lightThemeIconPath);
    }
}

/**
 * Set the low power icon based on the current theme.
 * @param {string} theme - The current theme ("light" or "dark").
 */
function setLowPowerIcon(theme) {
    const iconPathLowPower = document.getElementById("iconPathLowPower");
    const lowPowerIcon = document.getElementById("lightingIcon");
    if (theme === "dark") {
        lowPowerIcon.setAttribute("viewBox", "0 0 384 512");
        iconPathLowPower.setAttribute("d", darkLowPowerIconPath);
    } else {
        lowPowerIcon.setAttribute("viewBox", "0 0 384 512");
        iconPathLowPower.setAttribute("d", lightLowPowerIconPath);
    }
}

/**
 * Toggle between light and dark themes.
 */
function toggleTheme() {
    const htmlElement = document.documentElement;
    const currentTheme = htmlElement.getAttribute("theme");
    const newTheme = currentTheme === "dark" ? "light" : "dark";
    console.debug("Toggle theme function called");
    console.debug("Current theme:", currentTheme);
    console.debug("New theme:", newTheme);
    htmlElement.setAttribute("theme", newTheme);
    console.debug("Theme set to:", newTheme);
    localStorage.setItem("theme", newTheme);
    setThemeIcon(newTheme);
    setLowPowerIcon(newTheme);
}

/**
 * Initialize the theme based on the saved preference in localStorage.
 */
function initializeTheme() {
    const savedTheme = localStorage.getItem("theme");
    if (savedTheme) {
        document.documentElement.setAttribute("theme", savedTheme);
        setThemeIcon(savedTheme);
        setLowPowerIcon(savedTheme);
    } else {
        setThemeIcon('light'); // Default theme
        setLowPowerIcon('light'); // Default low power icon
    }
}

/**
 * Initialize the theme switch event listener.
 */
function initializeThemeSwitch() {
    const colorSwitch = document.querySelector("#iconBulb");
    if (colorSwitch) {
        colorSwitch.addEventListener("click", toggleTheme);
    } else {
        console.error('Element with ID "iconBulb" not found.');
    }
}

document.addEventListener("DOMContentLoaded", function () {
    initializeTheme();
    initializeThemeSwitch();

    // Llamar a la funciÃ³n goLowPower al hacer clic en el icono de bajo consumo
    document.getElementById('lightingIcon').addEventListener('click', goLowPower);
});

/**
 * Sets the captive portal settings and sends them to the server.
 * @param {number} timeToWait - The time to wait for the captive portal.
 * @param {boolean} isInitialSetup - Whether this is the initial setup.
 */
function setCaptivePortalSettings(timeToWait, isInitialSetup = false) {

    // captivePortalNoTimeout is not loaded with the form value to obey the override from the URL

    // const disableTimeoutCheckbox = document.getElementById('cpNoTimeout');
    // captivePortalNoTimeout = disableTimeoutCheckbox ? disableTimeoutCheckbox.checked : false;

    // if (!disableTimeoutCheckbox && !isInitialSetup) {
    //     console.error('Element with ID "cpNoTimeout" not found.');
    //     return;
    // }

    // if (captivePortalDebug) {
    //     console.log('Setting captivePortalNoTimeout to:', captivePortalNoTimeout);
    //     console.log('Time to wait for timeout:', timeToWait);
    // }

    // if (disableTimeoutCheckbox && disableTimeoutCheckbox.checked) {
    //     if (captivePortalDebug || forcedCaptivePortalDebug) console.log('Disabling timeout for captive portal');
    //     timeToWait = 0;
    //     captivePortalNoTimeout = true;
    // }

    fetch('/setCaptivePortalSettings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            timeToWaitForCaptivePortal: timeToWait,
            captivePortalActive,
            captivePortalNoTimeout,
            forcedCaptivePortal,
            captivePortalDebug,
            relaxedSecurity: relaxedSecurity ? true : undefined
        })
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            if (captivePortalDebug) {
                console.log('Captive Portal settings updated on server successfully:', {
                    forcedCaptivePortal,
                    captivePortalActive,
                    captivePortalNoTimeout,
                    timeToWaitForCaptivePortal: timeToWait,
                    captivePortalDebug,
                    relaxedSecurity
                });
            }
        })
        .catch(error => console.error('Error setting captive portal settings:', error));
}

/**
 * Stores the captive portal status in the captivePortalStatus object.
 * @param {Object} data - The data containing the captive portal status.
 */
function storeCaptivePortalStatus(data) {
    captivePortalStatus.captivePortalTimeLeft = data.captivePortalTimeLeft;
}

/**
 * Handles the response data from the captive portal status fetch and updates the UI.
 * @param {Object} data - The data received from the server.
 */
function handleCaptivePortalData(data) {
    try {
        storeCaptivePortalStatus(data);
        const changes = checkForPropertyChanges(data);
        logPropertyChanges(changes);

        updateDebugMode(data);
        updateActiveStates(data);
        // updateStatusBarContent();

        if (debugWindowActive) {
            updateDebugWindow(data);
        }
    } catch (error) {
        console.error('Error in handleCaptivePortalData function:', error);
        throw error;
    }
}

/**
 * Checks for changes in specific properties compared to previous data.
 * @param {Object} data - The data received from the server.
 * @returns {Object} - Object containing changes in properties.
 */
function checkForPropertyChanges(data) {
    const changes = {};
    const propertiesToCheck = ['forceCaptivePortalActive', 'captivePortalActive', 'forcedCaptivePortal', 'captivePortalDebug', 'relaxedSecurity', 'forcedCaptivePortalDebug', 'captivePortalNoTimeout'];

    propertiesToCheck.forEach(key => {
        if (data[key] !== previousData[key]) {
            changes[key] = { previous: previousData[key], current: data[key] };
            previousData[key] = data[key];
        }
    });

    return changes;
}

/**
 * Logs changes in properties to the console.
 * @param {Object} changes - Object containing changes in properties.
 */
function logPropertyChanges(changes) {
    if (Object.keys(changes).length > 0) {
        console.log('Detected changes in captive portal data:', changes);
    }
}

/**
 * Updates the debug mode if present in the data.
 * @param {Object} data - The data received from the server.
 */
function updateDebugMode(data) {
    if (data.captivePortalDebug !== undefined) {
        if (data.captivePortalDebug !== captivePortalDebug) {
            captivePortalDebug = data.captivePortalDebug;
            console.log('Captive portal debug mode set to:', captivePortalDebug);
        }
    }
}

/**
 * Updates the active states based on the data received.
 * @param {Object} data - The data received from the server.
 */
function updateActiveStates(data) {
    forcedCaptivePortal = data.forceCaptivePortalActive || false;
    captivePortalActive = (data.captivePortalActive || false) || forcedCaptivePortal;
}

/**
 * Fetches the captive portal settings from the server.
 */
function getCaptivePortalSettings() {
    fetch("/getCaptivePortalStatusAsJson")
        .then(response => {
            // if (captivePortalDebug) console.log("Received response:", response);

            // Check if the response status is OK
            if (!response.ok) {
                console.error("Response not OK:", response.status, response.statusText);
                throw new Error("Network response was not ok " + response.statusText);
            }

            // Convert the response body to JSON
            return response.json();
        })
        .then(captivePortalSettings => {
            // if (captivePortalDebug) console.log("Received JSON:", captivePortalSettings);

            // Handle the JSON data
            try {
                handleCaptivePortalData(captivePortalSettings);
            } catch (e) {
                console.error("Error in handleCaptivePortalData:", e);
                throw e; // Re-throw the error to be caught in the catch block
            }
        })
        .catch(error => {
            console.error("Error fetching captive portal status:", error);
            // showServerStatusDot(true, "status-dot-red", "Connection to server lost");
        });
}

/**
 * Sets up the initial settings based on URL parameters.
 */
function setupInitialSettings() {
    if (window.location.href.includes("forcedCaptivePortal")) {
        if (captivePortalDebug) console.log('Forcing captive portal to be active in test mode by forcedCaptivePortal parameter in URL');
        forcedCaptivePortal = true;
        captivePortalActive = true;
    }

    if (window.location.href.includes("debugCaptivePortal")) {
        forcedCaptivePortalDebug = true;
        captivePortalDebug = true;
        console.log('Forcing captive portal debug mode to be active by debugCaptivePortal parameter in URL');
    }

    setCaptivePortalSettings(60, true);
}

/**
 * Initialize the captive portal for preferences.html.
 */
function initializeCaptivePortal() {
    if (captivePortalDebug) console.log('Document loaded. Initializing captive portal for preferences.html');

    getFeaturesAsJson(); // Fetch features from the server
    if (features.SUPPORT_OTA) {
        const otaLink = document.getElementById('otaLink');
        if (otaLink) {
            otaLink.classList.remove('hidden');
        } else {
            console.error('Element with ID "otaLink" not found.');
        }
    }

    // getCaptivePortalSettings(); // Fetch initial settings
    setupInitialSettings();

    setInterval(getCaptivePortalSettings, 1000);
}


/**
 * Shows or hides the captivePortalSettings fieldset based on the provided flag.
 * @param {boolean} show - Determines whether to show or hide the captivePortalSettings fieldset.
 */
function showCaptivePortalSettings(show) {
    const captivePortalSettings = document.getElementById('captivePortalSettings');
    if (captivePortalSettings) {
        if (show) {
            captivePortalSettings.classList.remove('hidden');
        } else {
            captivePortalSettings.classList.add('hidden');
        }
    } else {
        console.error('Element with ID "captivePortalSettings" not found.');
    }
}

/**
 * Adjust the padding-top of the content based on the navbar height.
 */
function adjustContentPadding() {
    const navbar = document.querySelector('.navbar');
    const content = document.querySelector('.content');

    if (navbar && content) {
        const navbarHeight = navbar.offsetHeight;
        content.style.paddingTop = `${navbarHeight}px`;
    }
}

document.addEventListener("DOMContentLoaded", function () {
    const currentPage = window.location.pathname.split("/").pop();

    adjustContentPadding();

    if (currentPage === "preferences.html") {
        initializeCaptivePortal();
        highlightCurrentPage(); // Highlight the current page in the navigation bar

        const debugWindow = document.getElementById('debug-window');
        if (captivePortalDebug || debugWindowActive) {
            if (debugWindow) {
                createDebugWindow(debugWindow);
                debugWindowActive = true;
                debugWindow.style.display = 'block';
            } else {
                console.error('Element with ID "debug-window" not found.');
            }
        } else {
            if (debugWindow) {
                debugWindow.style.display = 'none';
                debugWindowActive = false;
            }
        }
    } else {
        if (captivePortalDebug) console.log('Not on preferences.html, skipping debug window initialization');
    }


});
var captivePortalStatusBarActive = false;
var forcedCaptivePortalStatusBar = false;
var captivePortalStatusBarDebug = true;


/**
 * Updates the status bar content and sets up the event listener for the disable timeout checkbox.
 */
function updateStatusBarContent() {
    if (captivePortalActive) {
        // if (captivePortalDebug) console.log('Captive portal active. Showing status bar');
        // updateStatusBar('Captive portal active (test mode)');

        const statusBarContentElement = document.getElementById('status-bar-content');
        // Timeout time: captivePortalStatus.captivePortalTimeLeft
        if (statusBarContentElement) {
            if (!captivePortalNoTimeout) {
                // set id="disableTimeoutCheckbox" to unchecked
                statusBarContentElement.innerHTML = `
                <span>Timeout: <strong>${captivePortalStatus.captivePortalTimeLeft}</strong> seconds</span>
                <label><input type="checkbox" id="disableTimeoutCheckbox"> Disable</label>
            `;
            } else {
                // set id="disableTimeoutCheckbox" to checked
                statusBarContentElement.innerHTML = `
                <span>Timeout: <strong>Disabled</strong></span>
                <label><input type="checkbox" id="disableTimeoutCheckbox" checked> Disable</label>
            `;
            }
        } else {
            console.error('Element with ID "status-bar-content" not found.');
        }

        const disableTimeoutCheckbox = document.getElementById('disableTimeoutCheckbox');
        if (disableTimeoutCheckbox) {
            disableTimeoutCheckbox.checked = captivePortalNoTimeout;
            disableTimeoutCheckbox.addEventListener('change', function () {
                const timeToWait = this.checked ? 0 : 60;
                captivePortalNoTimeout = this.checked;
                console.log('Setting time to wait:', timeToWait);
                console.log('Disabling timeout:', captivePortalNoTimeout);
                setCaptivePortalSettings(timeToWait);
            });
        }

        // if (captivePortalDebug) console.log('Setting initial captive portal settings');
        // setCaptivePortalSettings(60, true);
    } else {
        updateStatusBar('Captive portal inactive');
        showCaptivePortalStatusBar(false);
    }
}

/**
 * Shows or hides the captive portal status bar.
 * @param {boolean} show - Determines whether to show or hide the status bar.
 */
function showCaptivePortalStatusBar(show) {
    if (captivePortalStatusBarActive === show) return;

    const captivePortalStatusBar = document.getElementById('captive-portal-status-bar');
    if (captivePortalStatusBar) {
        if (captivePortalStatusBarDebug) console.log('Captive portal status bar found:', captivePortalStatusBar);

        if (show) {
            if (captivePortalStatusBarDebug) console.log('Showing captive portal status bar');
            captivePortalStatusBar.classList.remove('hidden-captive-portal-status-bar');
        } else {
            if (captivePortalStatusBarDebug) console.log('Hiding captive portal status bar');
            captivePortalStatusBar.classList.add('hidden-captive-portal-status-bar');
        }
        captivePortalStatusBarActive = show;
    } else {
        console.error('Element with ID "captive-portal-status-bar" not found.');
    }
}

/**
 * Initializes the Captive Portal Status Bar.
 */
function initializeCaptivePortalStatusBar() {
    if (captivePortalStatusBarDebug) console.log('Initializing captive portal status bar');

    const captivePortalStatusBar = document.getElementById('captive-portal-status-bar');
    if (captivePortalStatusBar) {
        if (captivePortalStatusBarDebug) console.log('Injecting captive portal status bar content');
        captivePortalStatusBar.innerHTML = `
            <span id="status-bar-content"></span>
            <span id="hide-captive-portal-status-bar-button" onclick="showCaptivePortalStatusBar(false)">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="12" cy="12" r="10" stroke="black" stroke-width="2"/>
                    <line x1="8" y1="8" x2="16" y2="16" stroke="black" stroke-width="2"/>
                    <line x1="16" y1="8" x2="8" y2="16" stroke="black" stroke-width="2"/>
                </svg>
            </span>
        `;
        if (forcedCaptivePortal) showCaptivePortalStatusBar(true);
    } else {
        console.error('Element with ID "captive-portal-status-bar" not found.');
    }
}

function initializeCaptivePortalStatusBarUrlParameters() {
    captivePortalStatusBarDebug = window.location.href.includes("captivePortalStatusBarDebug");
    if (captivePortalStatusBarDebug) console.log('Captive portal status bar debug:', captivePortalStatusBarDebug);
    forcedCaptivePortalStatusBar = window.location.href.includes("forcedCaptivePortalStatusBar");
    if (captivePortalStatusBarDebug) console.log('Captive portal status bar forced:', forcedCaptivePortalStatusBar);
}

/**
 * Updates the content of the status bar.
 * @param {string} content - The content to display in the status bar.
 */
function updateStatusBar(content) {
    if (!captivePortalStatusBarActive) return;
    if (captivePortalStatusBarDebug) console.log('Updating status bar');
    const statusContent = document.getElementById('status-bar-content');
    if (statusContent) {
        statusContent.textContent = content;
        if (captivePortalStatusBarDebug) console.log('Updating status bar content:', content);
    } else {
        console.error('Element with ID "status-bar-content" not found.');
    }
}

document.addEventListener("DOMContentLoaded", function () {
    initializeCaptivePortalStatusBarUrlParameters();
    initializeCaptivePortalStatusBar();
    // setInterval(updateStatusBar, 1000);
    setInterval(updateStatusBarContent, 1000);
});
var canPingServer = true;

let previousServerStatusDotState = {
    show: null,
    colorClass: '',
    title: ''
};

/**
 * Shows or hides the server status dot based on the provided flag.
 * @param {boolean} show - Determines whether to show or hide the server status dot.
 * @param {string} [colorClass] - The color class to apply.
 * @param {string} [title] - The title to apply for hover text.
 */
function displayServerStatusDot(show, colorClass = 'status-dot-cyan', title = '') {
    const serverStatusDot = document.getElementById('server-status-dot');
    if (serverStatusDot) {
        const hasStateChanged =
            previousServerStatusDotState.show !== show ||
            previousServerStatusDotState.colorClass !== colorClass ||
            previousServerStatusDotState.title !== title;

        if (hasStateChanged) {
            serverStatusDot.className = 'status-dot'; // Reset class
            serverStatusDot.classList.add(show ? colorClass : 'status-dot-hidden');
            serverStatusDot.title = title;

            if (captivePortalDebug) {
                console.log(`Server status dot updated: show=${show}, colorClass=${colorClass}, title=${title}`);
            }

            // Update previous state
            previousServerStatusDotState.show = show;
            previousServerStatusDotState.colorClass = colorClass;
            previousServerStatusDotState.title = title;
        }
    } else {
        console.error('Element with ID "server-status-dot" not found.');
    }
}

/**
 * Checks the server connection periodically.
 */
function checkServerConnection() {
    fetch('/pingServer')
        .then(response => {
            if (response.ok) {
                canPingServer = true;
            } else {
                canPingServer = false;
                captivePortalActive = false; // Mark captive portal as inactive
            }
        })
        .catch(error => {
            console.error('Error pinging server:', error);
            captivePortalActive = false; // Mark captive portal as inactive
        });
}

/**
 * Updates the server status dot based on the captive portal status.
 */
function updateServerStatusDot() {
    let show, colorClass, title;

    if (!canPingServer) {
        show = true;
        colorClass = 'status-dot-red';
        title = 'Connection to server lost';
    } else if (!captivePortalActive) {
        show = false;
        colorClass = 'status-dot-hidden';
        title = 'Captive portal inactive';
    } else if (forcedCaptivePortal) {
        show = true;
        colorClass = 'status-dot-blue';
        title = 'Captive portal active (test mode)';
    } else {
        show = true;
        colorClass = 'status-dot-cyan';
        title = 'Captive portal active';
    }

    // Call displayServerStatusDot with the new state
    displayServerStatusDot(show, colorClass, title);

    // if (captivePortalDebug) {
    //     console.log('Updated server status dot based on captive portal status');
    //     console.log('captivePortalActive:', captivePortalActive, 'forcedCaptivePortal:', forcedCaptivePortal);
    // }
}

document.addEventListener("DOMContentLoaded", function () {
    setInterval(updateServerStatusDot, 1000);
    setInterval(checkServerConnection, 1000);
});
// Function to fetch version information from the server and display it in the status line
function displayVersion() {
    getVersionStr()
        .then(versionText => {
            document.getElementById("co2GadgetVersion").innerText = "CO2 Gadget: " + versionText;
        })
        .catch(error => {
            console.error('Error:', error);
        });
}

function openTab(evt, tabName) {
    var i, tabContent, tabLinks;
    tabContent = document.getElementsByClassName("tab-content");
    for (i = 0; i < tabContent.length; i++) {
        tabContent[i].style.display = "none";
    }
    tabLinks = document.getElementsByClassName("tab");
    for (i = 0; i < tabLinks.length; i++) {
        tabLinks[i].className = tabLinks[i].className.replace(" active", "");
    }
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
}

function toggleTab(tabName) {
    var tabContent = document.getElementById(tabName);
    var checkbox = document.getElementById("chk" + tabName);
    if (checkbox.checked) {
        tabContent.style.display = "block";
    } else {
        tabContent.style.display = "none";
    }
}

function toggle(checkboxId, elementId) {
    const checkbox = document.getElementById(checkboxId);
    if (!checkbox) {
        console.error('Checkbox with id ' + checkboxId + ' is not found.');
        return;
    }
    const element = document.getElementById(elementId);

    if (!element) {
        console.error('Element with id ' + elementId + ' is not found.');
        return;
    }

    // Function to toggle element visibility
    function toggleElement() {
        element.style.display = checkbox.checked ? 'block' : 'none';
        // if (checkbox.checked) {
        //     element.style.display = 'block'; // Show the element if checkbox is checked
        // } else {
        //     element.style.display = 'none'; // Hide the element if checkbox is unchecked
        // }
    }

    // Call toggleElement initially to set initial state
    toggleElement();

    // Add event listener to checkbox to update visibility when checkbox state changes
    checkbox.addEventListener('change', toggleElement);
}

function setCombineMode(andRadioId, orRadioId, combineWithAnd) {
    const useAnd = !!combineWithAnd;
    document.getElementById(andRadioId).checked = useAnd;
    document.getElementById(orRadioId).checked = !useAnd;
}

function loadThresholdsFromServer() {
    fetch('/getThresholdsAsJson')
        .then(response => response.json())
        .then(data => {
            console.log(data);
            document.getElementById("chkDisplay").checked = data[0].enabled;
            document.getElementById("keepAliveTimeDisplay").value = data[0].thrKeepAlive;
            document.getElementById("thrOnlyInLowPDisplay").checked = data[0].thrOnlyInLowP;
            document.getElementById("co2ThresholdAbsDisplay").value = data[0].thrCo2Abs;
            document.getElementById("co2ThresholdPctDisplay").value = data[0].thrCo2Per;
            document.getElementById("tempThresholdAbsDisplay").value = data[0].thrTempAbs;
            document.getElementById("tempThresholdPctDisplay").value = data[0].thrTempPer;
            document.getElementById("humThresholdAbsDisplay").value = data[0].thrHumAbs;
            document.getElementById("humThresholdPctDisplay").value = data[0].thrHumPer;
            setCombineMode("co2ThresholdAnd", "co2ThresholdOr", data[0].thrCo2CombAnd);
            setCombineMode("tempThresholdAnd", "tempThresholdOr", data[0].thrTempCombAnd);
            setCombineMode("humThresholdAnd", "humThresholdOr", data[0].thrHumCombAnd);

            document.getElementById("chkBluetooth").checked = data[1].enabled;
            document.getElementById("keepAliveTimeBluetooth").value = data[1].thrKeepAlive;
            document.getElementById("thrOnlyInLowPBluetooth").checked = data[1].thrOnlyInLowP;
            document.getElementById("co2ThresholdAbsBluetooth").value = data[1].thrCo2Abs;
            document.getElementById("co2ThresholdPctBluetooth").value = data[1].thrCo2Per;
            document.getElementById("tempThresholdAbsBluetooth").value = data[1].thrTempAbs;
            document.getElementById("tempThresholdPctBluetooth").value = data[1].thrTempPer;
            document.getElementById("humThresholdAbsBluetooth").value = data[1].thrHumAbs;
            document.getElementById("humThresholdPctBluetooth").value = data[1].thrHumPer;
            setCombineMode("co2ThresholdAndBluetooth", "co2ThresholdOrBluetooth", data[1].thrCo2CombAnd);
            setCombineMode("tempThresholdAndBluetooth", "tempThresholdOrBluetooth", data[1].thrTempCombAnd);
            setCombineMode("humThresholdAndBluetooth", "humThresholdOrBluetooth", data[1].thrHumCombAnd);

            document.getElementById("chkMQTT").checked = data[2].enabled;
            document.getElementById("keepAliveTimeMQTT").value = data[2].thrKeepAlive;
            document.getElementById("thrOnlyInLowPMQTT").checked = data[2].thrOnlyInLowP;
            document.getElementById("co2ThresholdAbsMQTT").value = data[2].thrCo2Abs;
            document.getElementById("co2ThresholdPctMQTT").value = data[2].thrCo2Per;
            document.getElementById("tempThresholdAbsMQTT").value = data[2].thrTempAbs;
            document.getElementById("tempThresholdPctMQTT").value = data[2].thrTempPer;
            document.getElementById("humThresholdAbsMQTT").value = data[2].thrHumAbs;
            document.getElementById("humThresholdPctMQTT").value = data[2].thrHumPer;
            setCombineMode("co2ThresholdAndMQTT", "co2ThresholdOrMQTT", data[2].thrCo2CombAnd);
            setCombineMode("tempThresholdAndMQTT", "tempThresholdOrMQTT", data[2].thrTempCombAnd);
            setCombineMode("humThresholdAndMQTT", "humThresholdOrMQTT", data[2].thrHumCombAnd);

            document.getElementById("chkESPNOW").checked = data[3].enabled;
            document.getElementById("keepAliveTimeESPNOW").value = data[3].thrKeepAlive;
            document.getElementById("thrOnlyInLowPESPNOW").checked = data[3].thrOnlyInLowP;
            document.getElementById("co2ThresholdAbsESPNOW").value = data[3].thrCo2Abs;
            document.getElementById("co2ThresholdPctESPNOW").value = data[3].thrCo2Per;
            document.getElementById("tempThresholdAbsESPNOW").value = data[3].thrTempAbs;
            document.getElementById("tempThresholdPctESPNOW").value = data[3].thrTempPer;
            document.getElementById("humThresholdAbsESPNOW").value = data[3].thrHumAbs;
            document.getElementById("humThresholdPctESPNOW").value = data[3].thrHumPer;
            setCombineMode("co2ThresholdAndESPNOW", "co2ThresholdOrESPNOW", data[3].thrCo2CombAnd);
            setCombineMode("tempThresholdAndESPNOW", "tempThresholdOrESPNOW", data[3].thrTempCombAnd);
            setCombineMode("humThresholdAndESPNOW", "humThresholdOrESPNOW", data[3].thrHumCombAnd);

            // Toggle visibility of tabs based on checkbox state
            toggle('chkDisplay', 'Display');
            toggle('chkBluetooth', 'Bluetooth');
            toggle('chkMQTT', 'MQTT');
            toggle('chkESPNOW', 'ESPNOW');
        })
        .catch(error => console.error('Error retrieving thresholds:', error));
}

function loadPreferencesFromServer() {
    fetch('/getActualSettingsAsJson')
        .then(response => response.json())
        .then(data => {
            console.log(data);
            // Actualiza los campos de Low Power Options
            document.getElementById("lowPowerMode").value = data.lowPowerMode;
            document.getElementById("waitToDeep").value = data.waitToDeep;
            document.getElementById("timeSleeping").value = data.timeSleeping;
            document.getElementById("cyclsWifiConn").value = data.cyclsWifiConn;
            document.getElementById("cycRedrawDis").value = data.cycRedrawDis;
            document.getElementById("actBLEOnWake").checked = data.actBLEOnWake;
            document.getElementById("actWifiOnWake").checked = data.actWifiOnWake;
            document.getElementById("actMQTTOnWake").checked = data.actMQTTOnWake;
            document.getElementById("actESPnowWake").checked = data.actESPnowWake;
            document.getElementById("deepSleepData.displayOnWake").checked = data.displayOnWake;
        })
        .catch(error => console.error('Error retrieving preferences:', error));
}

function collectThresholdsData() {
    // Collect preferences data from the form
    var thresholdsData = {
        "thresholds": [
            {
                "enabled": document.getElementById("chkDisplay").checked,
                "thrOnlyInLowP": document.getElementById("thrOnlyInLowPDisplay").checked,
                "thrKeepAlive": document.getElementById("keepAliveTimeDisplay").value,
                "thrCo2Abs": document.getElementById("co2ThresholdAbsDisplay").value,
                "thrTempAbs": document.getElementById("tempThresholdAbsDisplay").value,
                "thrHumAbs": document.getElementById("humThresholdAbsDisplay").value,
                "thrCo2Per": document.getElementById("co2ThresholdPctDisplay").value,
                "thrTempPer": document.getElementById("tempThresholdPctDisplay").value,
                "thrHumPer": document.getElementById("humThresholdPctDisplay").value,
                "thrCo2CombAnd": document.getElementById("co2ThresholdAnd").checked,
                "thrTempCombAnd": document.getElementById("tempThresholdAnd").checked,
                "thrHumCombAnd": document.getElementById("humThresholdAnd").checked
            },
            {
                "enabled": document.getElementById("chkBluetooth").checked,
                "thrOnlyInLowP": document.getElementById("thrOnlyInLowPBluetooth").checked,
                "thrKeepAlive": document.getElementById("keepAliveTimeBluetooth").value,
                "thrCo2Abs": document.getElementById("co2ThresholdAbsBluetooth").value,
                "thrTempAbs": document.getElementById("tempThresholdAbsBluetooth").value,
                "thrHumAbs": document.getElementById("humThresholdAbsBluetooth").value,
                "thrCo2Per": document.getElementById("co2ThresholdPctBluetooth").value,
                "thrTempPer": document.getElementById("tempThresholdPctBluetooth").value,
                "thrHumPer": document.getElementById("humThresholdPctBluetooth").value,
                "thrCo2CombAnd": document.getElementById("co2ThresholdAndBluetooth").checked,
                "thrTempCombAnd": document.getElementById("tempThresholdAndBluetooth").checked,
                "thrHumCombAnd": document.getElementById("humThresholdAndBluetooth").checked
            },
            {
                "enabled": document.getElementById("chkMQTT").checked,
                "thrOnlyInLowP": document.getElementById("thrOnlyInLowPMQTT").checked,
                "thrKeepAlive": document.getElementById("keepAliveTimeMQTT").value,
                "thrCo2Abs": document.getElementById("co2ThresholdAbsMQTT").value,
                "thrTempAbs": document.getElementById("tempThresholdAbsMQTT").value,
                "thrHumAbs": document.getElementById("humThresholdAbsMQTT").value,
                "thrCo2Per": document.getElementById("co2ThresholdPctMQTT").value,
                "thrTempPer": document.getElementById("tempThresholdPctMQTT").value,
                "thrHumPer": document.getElementById("humThresholdPctMQTT").value,
                "thrCo2CombAnd": document.getElementById("co2ThresholdAndMQTT").checked,
                "thrTempCombAnd": document.getElementById("tempThresholdAndMQTT").checked,
                "thrHumCombAnd": document.getElementById("humThresholdAndMQTT").checked
            },
            {
                "enabled": document.getElementById("chkESPNOW").checked,
                "thrOnlyInLowP": document.getElementById("thrOnlyInLowPESPNOW").checked,
                "thrKeepAlive": document.getElementById("keepAliveTimeESPNOW").value,
                "thrCo2Abs": document.getElementById("co2ThresholdAbsESPNOW").value,
                "thrTempAbs": document.getElementById("tempThresholdAbsESPNOW").value,
                "thrHumAbs": document.getElementById("humThresholdAbsESPNOW").value,
                "thrCo2Per": document.getElementById("co2ThresholdPctESPNOW").value,
                "thrTempPer": document.getElementById("tempThresholdPctESPNOW").value,
                "thrHumPer": document.getElementById("humThresholdPctESPNOW").value,
                "thrCo2CombAnd": document.getElementById("co2ThresholdAndESPNOW").checked,
                "thrTempCombAnd": document.getElementById("tempThresholdAndESPNOW").checked,
                "thrHumCombAnd": document.getElementById("humThresholdAndESPNOW").checked
            }
        ]
    };
    return thresholdsData;
}

function showSavingPopup() {
    // Show the popup
    document.getElementById("popup").style.display = "block";
    console.log("Show popup");

    // After 2 seconds, hide the popup
    setTimeout(function () {
        // Oculta el popup
        document.getElementById("popup").style.display = "none";
        console.log("Hide popup");
    }, 2000);
}

function saveThresholdsToServer() {
    // Collect Thresholds data from the form
    var ThresholdsData = collectThresholdsData();
    console.log("Sending Thresholds to server:", ThresholdsData);

    return fetch('/saveThresholds', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(ThresholdsData)
    })
        .then(response => {
            if (!response.ok) {
                throw new Error(`Error updating thresholds. Status: ${response.status}`);
            }
            console.log("Thresholds updated successfully!");
        });
}

function savePreferencesToServer() {
    // Collect preferences data from the form
    var lowPowerData = {
        "lowPowerMode": document.getElementById("lowPowerMode").value,
        "waitToDeep": document.getElementById("waitToDeep").value,
        "timeSleeping": document.getElementById("timeSleeping").value,
        "cyclsWifiConn": document.getElementById("cyclsWifiConn").value,
        "cycRedrawDis": document.getElementById("cycRedrawDis").value,
        "actBLEOnWake": document.getElementById("actBLEOnWake").checked,
        "actWifiOnWake": document.getElementById("actWifiOnWake").checked,
        "actMQTTOnWake": document.getElementById("actMQTTOnWake").checked,
        "actESPnowWake": document.getElementById("actESPnowWake").checked,
        "displayOnWake": document.getElementById("deepSleepData.displayOnWake").checked
    };
    console.log("Sending Low Power preferences to server:", lowPowerData);
    return fetch('/savePreferences', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(lowPowerData)
    })
        .then(response => {
            if (response.ok) {
                if (preferencesDebug) console.log("Low Power Lreferences updated successfully!");
            } else {
                alert("Error updating preferences. Please try again.");
            }
        })
        .catch(error => console.error('Error saving Low Power preferences:', error));
}

function saveLowPowerToServer() {
    // Show a popup to indicate that the preferences are being saved
    showSavingPopup();
    saveThresholdsToServer()
        .then(() => savePreferencesToServer())
        .catch(error => {
            console.error('Error saving Low Power settings:', error);
            alert("Error updating low power settings. Please try again.");
        });
}

document.addEventListener("DOMContentLoaded", function () {
    // Get the current URL
    var currentURL = window.location.href;

    // Check if the current URL contains "status.html"
    if (currentURL.includes("low_power.html")) {
        highlightCurrentPage(); // Highlight the current page in the navigation bar
        displayVersion();
    }

    loadPreferencesFromServer();
    loadThresholdsFromServer();

    // Open the first active tab by default
    const tabs = document.querySelectorAll(".tab-content");
    let firstActiveTab = null;

    for (let tab of tabs) {
        const checkbox = document.getElementById("chk" + tab.id);
        if (checkbox && checkbox.checked) {
            firstActiveTab = tab;
            break;
        }
    }

    if (firstActiveTab) {
        firstActiveTab.style.display = "block";
        const tabLink = document.querySelector(`.tab[href="#${firstActiveTab.id}"]`);
        if (tabLink) {
            tabLink.className += " active";
        }
    }
});
